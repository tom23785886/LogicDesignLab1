#include <iostream>

using namespace std;
int count_cycle_length(int num);
int main()
{
    int start,last;
    int maxi;
    while(cin>>start>>last)
    {
        maxi=count_cycle_length(start);
        for(int i=start+1;i<=last;i++)
        {
            int a=count_cycle_length(i);
            if(a>maxi) maxi=a;
        }
        cout<<maxi<<endl;
    }
    return 0;
}
int count_cycle_length(int num)
{
    int c=1;
    while(num!=1)
    {
        c++;
        if(num%2==0)num/=2;
        else num=num*3+1;
    }
    return c;
}
